﻿/*
 * Created by SharpDevelop.
 * User: ityagi
 * Date: 6/27/2016
 * Time: 11:07 PM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;


class Solution {
	static void Main(String[] args) {
		/* Enter your code here. Read input from STDIN. Print output to STDOUT. Your class should be named Solution */
		int n = Int32.Parse(Console.ReadLine());
		int nfact=1;
		if(n>=2 && n<=12)
		{
			nfact = CalculateFact(n);
		}
		Console.WriteLine(nfact);
		Console.ReadKey();
	}
	public static int CalculateFact (int n)
	{
		int rfact = 1;
		if(n>1)
		{
			rfact = n * CalculateFact(n-1);
		}
		return rfact;
	}
}

